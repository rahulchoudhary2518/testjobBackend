var Sequelize = require('sequelize');
const users = require('../models').users
module.exports = {
    usersEmail(req, res) {
        console.log(res,"res")
    }
}